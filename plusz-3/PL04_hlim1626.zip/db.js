"use strict";


module.exports = [{
    id: 1,
    firstName: "Béla",
    lastName: "Kovács",
    address: "Valami u. 43. sz.",
    telephone: {
        number: "0741892132",
        units: 1000.0
    }
}, {
    id: 2,
    firstName: "István",
    lastName: "Kovács",
    address: "Valami u. 43. sz.",
    telephone: {
        number: "0741892133",
        units: 10.4
    }
}, {
    id: 3,
    firstName: "Dániel",
    lastName: "Kovács",
    address: "Valami u. 43. sz.",
    telephone: {
        number: "0741892134",
        units: 0.0
    }
}, {
    id: 4,
    firstName: "Gellért",
    lastName: "Kovács",
    address: "Valami u. 43. sz.",
    telephone: {
        number: "0741892135",
        units: 12.5
    }
}, {
    id: 5,
    firstName: "János",
    lastName: "Kovács",
    address: "Valami u. 43. sz.",
    telephone: {
        number: "0741892136",
        units: 76.00
    }
}];
